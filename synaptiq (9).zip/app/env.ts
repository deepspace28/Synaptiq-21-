// Remove NEXT_PUBLIC_GROQ_API_KEY from client-side code
// Only use server-side GROQ_API_KEY in API routes

export const env = {
  // Other environment variables can stay here if needed
  // But remove any sensitive keys that should not be exposed to the client
}
