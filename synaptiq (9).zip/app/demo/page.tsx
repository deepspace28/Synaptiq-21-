import { SynaptiqChat } from "@/components/chat/synaptiq-chat"

export default function DemoPage() {
  return <SynaptiqChat />
}
