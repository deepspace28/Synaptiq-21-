import type React from "react"
export default function QuantumDemoLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <>{children}</>
}
